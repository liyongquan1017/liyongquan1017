---
layout: 
title: 测试工程师知识图谱
date: 2020-05-30 15:00:52
tags: 
- 测试
---

### 前言

有很多同学对于测试工程师必备的测试技能不是很清晰，对自己以后的规划也不是很明了，不知道自己到底该从哪个方向努力或发展，下面是我从其他大佬那找的测试工程师必备知识图谱，也许能能给大家带来一些帮助。

<!--more-->

### 图谱

![TesterSkillMap3](https://ssd.qiniu.dreamfly95.com/TesterSkillMap3.png)

![TesterSkillMap2](https://ssd.qiniu.dreamfly95.com/TesterSkillMap2.png)![TesterSkillMap1](https://ssd.qiniu.dreamfly95.com/TesterSkillMap1.png)

​    来源：https://blog.csdn.net/timeorspace/article/details/69225354



### 结语

面朝大海，春暖花开。

愿你一生努力，一生被爱。

