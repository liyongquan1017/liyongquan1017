---
layout: 
title: 接口自动化框架之Unittest（3）
date: 2020-08-16 16:38:57
tags: 
- 接口测试
---

### 前言

做接口自动化，要用到Python的单元测试框架Unittest，是Python标准库自带的单元测试工具，也称为PyUnit，是JUnit（Java语言的单元测试）的Python版本。它支持测试自动化，将测试样例聚合到测试集中，并将测试与报告框架独立。

### 准备

1.  [Unittest官方文档](https://docs.python.org/zh-cn/3.8/library/unittest.html)
2. [优质视频教程](https://www.bilibili.com/video/BV1xJ411v7Eb)

### 具体示例





### 结语

面朝大海，春暖花开。

愿你一生努力，一生被爱。

