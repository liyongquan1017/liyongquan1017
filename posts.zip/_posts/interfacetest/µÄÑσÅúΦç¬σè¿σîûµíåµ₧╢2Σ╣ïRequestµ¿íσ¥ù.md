---
layout: 
title: 接口自动化框架之Request模块（2）
date: 2020-08-08 16:44:46
tags: 
- 接口测试
---

### 前言

要学接口自动化，或者爬虫等，Requests库的使用是必备知识，也是给你打开自动化大门的一把钥匙。

Requests的口号是为人类服务，也是唯一的一个**非转基因**的 Python HTTP 库，人类可以安全享用。

<!--more-->

### 准备

1.[安装Requests库方法](https://cn.python-requests.org/zh_CN/latest/user/install.html)

2.[Requests的官方文档](https://cn.python-requests.org/zh_CN/latest/user/quickstart.html)

3.可用于练习的免费接口：[聚合数据免费接口](https://www.juhe.cn/docs)（打开在筛选页，选择免费的，然后申请下就可以用了），[其他免费接口](https://api.apiopen.top/api.html)（由于被人乱刷，导致部分接口已被封禁）

4.了解[get和post的区别](https://www.jianshu.com/p/55c8708da06c)

### 具体示例

我们已 qq号测吉凶为例来演示Requests的基本用法，[qq号测吉凶API地址](https://www.juhe.cn/docs/api/id/166)。

```python
import requests

'''
网址：https://www.juhe.cn/docs/api/id/166
接口地址：http://japi.juhe.cn/qqevaluate/qq
返回格式：json
请求方式：get post
请求示例：http://japi.juhe.cn/qqevaluate/qq?key=您申请的appKey&qq=295424589
接口备注：根据传入的参数qq号码和您申请的appKey测试qq的吉凶

名称 必填 类型 说明
key    是  string 您申请的appKey
qq 是  string 需要测试的QQ号码

该接口支持get和 post请求
上面key需要自己注册账号后申请，是免费的。
'''


# 1.先来联系get请求,
# 方式一：直接请求,在请求地址后面直接拼接请求参数
rGet1 = requests.get('http://japi.juhe.cn/qqevaluate/qq?key=你申请的appkey&qq=要测试的QQ').json()
# print(rGet1)

# 方式二：定义请求参数，然后使用get请求
params = {'key':'你申请的appkey',
          'qq':'要测试的QQ'}
rGet2 = requests.get('http://japi.juhe.cn/qqevaluate/qq',params=params).json()
# print(rGet2)

# 2.用post请求来
data = {'key':'你申请的appkey',
          'qq':'要测试的QQ'}
rPost = requests.post('http://japi.juhe.cn/qqevaluate/qq',data=data).json()
print(rPost)

# 取出QQ的测试结果

# 方式一
qqResult = rPost['result']['data']['conclusion']

# 方式二，具体为何用get可以自行查阅资料
qqResult1 = rPost.get('result').get('data').get('conclusion')

print(qqResult1)
```

以上就是Requests 的基本用法，以后在编码过程中也要学会查看函数参数和方法。

学会Requests的用法就可以对接口做一些基本的操作了。



### 结语

面朝大海，春暖花开。

愿你一生努力，一生被爱。

