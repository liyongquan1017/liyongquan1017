---
layout: 
title: 代码管理(git,gitee,coding等)平台配置ssh
date: 2020年04月15日20:19:32
tags:
- 技巧
---

 

# git,gitee,coding等平台配置ssh

### git,gitee,coding等托管平台配置ssh的目的：

配置好ssh后可以让你的电脑和git,gitee,coding等平台通讯的时候建立可信任的安全连接

<!--more-->

###步骤：

1. 打开终端（windows下载[git windows 终端](https://gitforwindows.org/)，Mac直接用原生自带的terminal就OK）。

   - 输入` cd ~/.ssh`
   - 然后输入`ls`,查看是否有`id_rsa`和`id_rsa.pub`

   ![cdssh](https://ssd.qiniu.dreamfly95.com/cdssh.png)

   - 如果有则执行第2部，如果没有上述两个文件就执行 `ssh-keygen -trsa -C xxxxx@XXX.com`(xxxxx@XXX.com为你注册github时的邮箱)，然后开始执行第二部

   <!--注意：如果已有id_rsa和id_rsa.pub文件时，不要执行 ssh-keygen，不然会把你原有的ssh文件冲掉，原来配置过ssh的地方就失效了-->

2. 查看公钥内容

   - 执行`cat ~/.ssh/id_rsa.pub`

     ![catssh](https://ssd.qiniu.dreamfly95.com/catssh.png)

3. 复制公钥内容，全部内容，以ssh-rsa开头的全部内容。粘贴至你所要建立安全连接的平台，这里咦gitee为例：

   - 打开[gitee](https://gitee.com/)并登陆账户,按下图操作

     ![giteessh1](https://ssd.qiniu.dreamfly95.com/giteessh1.png)

   

   ![giteessh2](https://ssd.qiniu.dreamfly95.com/giteessh2.png)

   

   - 然后点击保存就OK了，其他例如 github,gitlab等都一样

4. 测试是否连接成功

   - 终端执行 `ssh -T git@gitee.com`   (@后面的可以换成你想要连接的平台的网址就OK)

   - 如果成功则会提示 You've successfully![giteessh3](https://ssd.qiniu.dreamfly95.com/giteessh3.png)

     

5. 完工！！！

