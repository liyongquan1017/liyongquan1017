---
layout: 
title: Markdown的使用
date: 2020-05-26 23:14:06
tags: 
- 技巧
---

### 前言

Markdown 是一种轻量级标记语言，它允许人们使用易读易写的纯文本格式编写文档。

Markdown 编写的文档后缀为 `.md`, `.markdown`，可以导出 HTML 、Word、图像、PDF、Epub 等多种格式的文档。当前许多网站都广泛使用 Markdown 来撰写帮助文档或是用于论坛上发表消息。例如：GitHub、简书等。

通俗一点讲，使用Markdown写文档可以让你的文档格式比较规范明了，看着比较优美，本文的教程就是用Markdown写的。

<!--more-->

### 准备

1.在线练习工具[Cmd Markdown 编辑阅读器](https://www.zybuluo.com/mdeditor)

2.客户端编写软件 [Typora](https://typora.io/)

> 注意 在线练习工具Cmd Markdown 编辑阅读器 和 客户端软件 Typora 有些语法会有差异大家自行甄别。

### 示例

给介绍几个常用的语法和最终的展示效果，具体的一些可以在 [Cmd Markdown 编辑阅读器](https://www.zybuluo.com/mdeditor) 中查阅

#### 1.标题

```
语法：
# 这是一级标题
## 这是二级标题
### 这是三级标题
#### 这是四级标题
##### 这是五级标题
###### 这是六级标题
```

展示效果：

![](https://ssd.qiniu.dreamfly95.com/Markdown1.png)

#### 2.字体

```
语法：
**这是加粗的文字**
*这是倾斜的文字*`
***这是斜体加粗的文字***
~~这是加删除线的文字~~
```

展示效果：

![](https://ssd.qiniu.dreamfly95.com/Markdown2.png)

#### 3.引用

```
语法：
>这是引用的内容
```

展示效果：

![](https://ssd.qiniu.dreamfly95.com/Markdown3.png)

#### 4.超链接

```
语法
[超链接名](超链接地址 "超链接title")

示例：
[百度](http://baidu.com)
```

展示效果：

![](https://ssd.qiniu.dreamfly95.com/Markdown4.png)

#### 5.图片

```
![图片描述](图片地址 ''图片title'')

图片alt就是显示在图片下面的文字，相当于对图片内容的解释，可加可不加
图片title是图片的标题，当鼠标移到图片上时显示的内容。title可加可不加

示例：

![风景](https://ss0.bdstatic.com/94oJfD_bAAcT8t7mm9GUKT-xh_/timg?image&quality=100&size=b4000_4000&sec=1590818510&di=f0e6467d2588dd1434e9fbb151653570&src=http://www.wndhw.com/fengjing/shanshui/images/ss003t4.jpg "风景")
```

展示效果：

![](https://ssd.qiniu.dreamfly95.com/Markdown5.png)

#### 6.代码块

```
 语法：
 
 `代码内容`
 
 
```
 我是代码块
 我是代码块
 我是代码块
 我是代码块
 ```

 ```

展示效果：

![](https://ssd.qiniu.dreamfly95.com/Markdown6.png)

以上是一些基本常用的。其他的语法大家可以在  [Cmd Markdown 编辑阅读器](https://www.zybuluo.com/mdeditor) 中查阅。



### 结语

面朝大海，春暖花开。

愿你一生努力，一生被爱。

