---
layout: 
title: 怎么打开iOS手机的开发者模式
date: 2020-07-04 16:55:48
tags: 
- 技巧
---

### 前言

iPhone手机也有开发者选项，这个功能开发或者测试同学都有很大的帮助，今天我们就把这个功能个如何打开，如何关闭，以及各个功能到底有什么作用给大家列一下。

<!-- more -->

### 准备

1.Xcode （本次文档中使用是 Xcode Version 11.5）

2.iPhone （本次文档中使用是 iPhone XR iOS13.5.1）

### 作用

开发者每个选项的作用：

**PAIRED DEVICES** 

Clear Trusted Computers 清除受信任的计算机

**INSTRUMENTS**

 Logging 点击进入  可以对电量和网络记录情况进行记录 记录的内容可以使用instruments查看。[使用方法](https://links.jianshu.com/go?to=http%3A%2F%2Fwww.cocoachina.com%2Fios%2F20180806%2F24469.html)

**Enable UI Automation**  是否允许UI自动化测试

 [iOS自动化测试 UI Automation]( https://www.jianshu.com/p/0e28ae1bd2c2)

**NETWORKING**
 Network Link Conditioner 网络链接调节器  模拟各种网络情况，可以对APP进行弱网测试。

**AD DEVELOPER APP TESTING** 广告开发者 app测试
 Fill Rate 填充率
 Ad Refresh Rate 广告刷新间隔
 Highlight Clipped Banners  突出显示剪贴横幅
 Unlimited Ad Presentation  无限广告展示

**PASSKIT TESTING** 测试
 Addtional Logging 附加登录
 Allow HTTP Services 允许http服务
 Disable Rate Limiting  禁止限制速率
 NFC Pass Key Optional NFC密码可选
 [官方链接](https://links.jianshu.com/go?to=https%3A%2F%2Fdeveloper.apple.com%2Fwallet%2F)

**NEWS TESTING**
 Reset Local Data on Next Launch. 下次启动时重置本地数据
 Reset layouts,images,and other cached elements. Private data will not be affected.
 重置布局、图像和其他缓存元素。私有数据不会受到影响。

### 打开方式

1. 用数据线连接mac和iPhone

2. 打开Xcode，选择 Xcode -> window -> Devices and Simulators，如图：

![image-20200704175313401](https://ssd.qiniu.dreamfly95.com/image-20200704175313401.png)

3. 选择自己的手机，右键单击选择Show Provisioning Profiles...，如图：

![image-20200704175458221](https://ssd.qiniu.dreamfly95.com/image-20200704175458221.png)

4. 在弹窗中的列表中查看，是否有开发者证书，如果没有，就点击“+”，添加开发者证书，完成后点击“Done”。如图：

   ![image-20200704175643841](https://ssd.qiniu.dreamfly95.com/image-20200704175643841.png)

5. 打开手机设置，在列表里就能看到开发者选项了。

   ![image-20200704175829746](https://ssd.qiniu.dreamfly95.com/image-20200704175829746.png)

### 关闭开发者选项

在未连接mac时，手机关机重启，开发者选项就消失。



### 资料来源

https://www.jianshu.com/p/8dc5787b4728



### 结语

面朝大海，春暖花开。

愿你一生努力，一生被爱。

