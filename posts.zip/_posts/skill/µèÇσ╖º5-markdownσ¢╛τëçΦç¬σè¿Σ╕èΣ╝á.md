---
layout: 
title: markdown图片自动上传
date: 2020-07-04 18:04:47
tags: 
- 技巧
---

### 前言

我们写markdown时，里面需要用到的图片，需要上传生成链接后在放到文档里面，图片一旦多了会很麻烦。

今天给大家推荐两款应用，结合使用，可以直接把要用的图片直接拖到markdown编写工具内，图片就会自动上传。

<!-- more -->

### 准备

1.[PicGo 图床管理工具](https://github.com/Molunerfinn/PicGo)

2.[Typore markdown编写工具](https://www.typora.io/)

> 本次使用的mac电脑，window电脑操作方式应该大体也一样

### 步骤

1.配置PicGo 图床管理工具，[使用文档](https://picgo.github.io/PicGo-Doc/zh/guide/getting-started.html)

2.打开Typore，选择 Typore => 偏好设置 => 图像，然后做如图配置：

![image-20200704181634536](https://ssd.qiniu.dreamfly95.com/image-20200704181634536.png)

3.点击验证图片上传选项，出现如图验证成功提示，就配置完成了。

![image-20200704181826122](https://ssd.qiniu.dreamfly95.com/image-20200704181826122.png)

4.这时就可以把本地图片拖到Typore里，图片就会自动传到云端了，大家快去体验一下吧。



### 结语

面朝大海，春暖花开。

愿你一生努力，一生被爱。

