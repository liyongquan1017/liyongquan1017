---
layout: 
title: Python之构造请求参数（1）
date: 2020-05-25 16:38:57
tags: 
- 接口测试
---

### 前言

接口测试中，我们需要去手动输入请求参数组合，因为输入法等问题，可能会造成标点或括号等输错，最后出错后，还不大好排查。因此我们通过构造请求参数，能大大避免这类问题的发生。这也是最基础的知识，

> 另我们使用Postman输入请求参数时，也可以先用Python构造请求参数，然后再使用。不过这个因人而异，如果你对自己有信心，直接手拼也OK。

<!--more-->

### 准备

1. Python3.0 + 编译工具（推荐Pycharm）
2. 了解Python  [dict（字典)](https://www.runoob.com/python/python-dictionary.html)，[list（列表)](https://www.runoob.com/python/python-lists.html)，[json](https://www.runoob.com/python/python-json.html)等的基本知识

### 具体示例

假如一个请求内的请求参数表如下，我们无需去管这个是哪个接口的参数，也不用管里面的内容，我们的目的是了解参数的构造，以及对一些基本知识的应用。

| 名称        | 类型     | 是否必传 | 说明                                                         |
| ----------- | -------- | -------- | ------------------------------------------------------------ |
| id          | string   | 是       | 用户ID。例如：520                                            |
| comment     | string   | 是       | 发布内容                                                     |
| tagIdList   | Jsonlist | 是       | 使用标签，标签ID可传多个。如       [{'tagid':1},{'tagid':2}] |
| otherIDinfo | Jsonlist | 是       | @其他的人信息                      [{'id':'123','name':'梦想'},{'id:'456','name':'飞翔'}] |
| button_type | String   | 是       | 按钮位置   朋友圈：friend   广场：square                     |
| type        | Int      | 是       | 是否开放   开放：1     不开放：0                             |



具体代码如下：

```python
import json

'''
接下来我们我们开始构造一个请求参数，具体需要传入的值如下：

用户ID为             456
发布内容为            构造参数
使用的标签ID为        1，2和3
@的人的信息为(前面为名字，后面为ID)    梦想，123  飞翔，456
开放类型为           不开放

'''
# 1.定义一个字典类型testDict，用于存放整个请求参数
testDict = {}
# 2.请求参数中加入用户ID,ID为string类型
testDict['id'] = '456'
# 3.请求参数中加入发布内容comment，为string类型
testDict['comment']= '构造参数'
# 4.请求参数中加入标签tagIdList，因为标签是list类型，因为我们要传入三个标签，所以需要拼接
tagIdlists = []     #定义一个存放标签集的list
tagids = {}         #定义一个存放ID的字典
tagids['tagid'] =1  #加入标签为1的标签
#把标签为1拼接 到标签集里面，使用json.dumps的原因是把字典转换为字符串格式，避免后面tagids['tagid']赋值时把前面覆盖
tagIdlists.append(json.dumps(tagids))
tagids['tagid'] =2
tagIdlists.append(json.dumps(tagids))  #把标签为2拼接 到标签集里面
tagids['tagid'] =3
tagIdlists.append(json.dumps(tagids))  #把标签为3拼接 到标签集里面
testDict['tagIdList'] = tagIdlists  # 把标签集加入到我们的请求参数内
# 5.请求参数中加入需要@的人的信息otherIDinfo,基本和步骤四类似
otherInfos =[]
otherIn = {}
otherIn['id'] = '123'
otherIn['name'] = '梦想'
otherInfos.append(json.dumps(otherIn,ensure_ascii=False))
otherIn['id'] = '456'
otherIn['name'] = '飞翔'
otherInfos.append(json.dumps(otherIn,ensure_ascii=False))
testDict['otherIDinfo'] = otherInfos # 把需要@的人的信加入到我们的请求参数内
# 6.请求参数中加入 是否开放的信息
testDict['type'] = 0
# 7.把请求参数转换为json格式
print(testDict)
```

此时打印出来的为：

> {'id': '456', 'comment': '构造参数', 'tagIdList': ['{"tagid": 1}', '{"tagid": 2}', '{"tagid": 3}'], 'otherIDinfo': ['{"id": "123", "name": "梦想"}', '{"id": "456", "name": "飞翔"}'], 'type': 0}

这时我们打印出来的实际为字典类型，实际中我们需要传入的请求参数为json格式，所以我们需要把字典转换为json格式，我们可以在代码最后加入两行

```python

# 7.把请求参数转换为json格式
testDict = json.dumps(testDict)
print(testDict)
```

这时打印出来的如下

> {"id": "456", "comment": "\u6784\u9020\u53c2\u6570", "tagIdList": ["{\"tagid\": 1}", "{\"tagid\": 2}", "{\"tagid\": 3}"], "otherIDinfo": ["{\"id\": \"123\", \"name\": \"\u68a6\u60f3\"}", "{\"id\": \"456\", \"name\": \"\u98de\u7fd4\"}"], "type": 0}

我们发现转换后出现，汉字变为Unicode码的问题，这时我们需要在转换时，加入一个参数`ensure_ascii=False`避免中文转为Unicode码。

```python
# 7.把请求参数转换为json格式
testDict = json.dumps(testDict,ensure_ascii=False)
print(testDict)
```

这时打印出来的就是符合规范的请求参数

> {"id": "456", "comment": "构造参数", "tagIdList": ["{\"tagid\": 1}", "{\"tagid\": 2}", "{\"tagid\": 3}"], "otherIDinfo": ["{\"id\": \"123\", \"name\": \"梦想\"}", "{\"id\": \"456\", \"name\": \"飞翔\"}"], "type": 0}



### 结语

面朝大海，春暖花开。

愿你一生努力，一生被爱。

