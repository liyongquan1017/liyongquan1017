---
layout: 
title: Python之模拟抽奖概率计算（3）
date: 2020-05-31 22:54:21
tags: 
- 接口测试
---

### 前言

在很多公司测试过程中会有抽奖概率测试，如果用手动去模拟，会很不现实，一般都是从接口入手，模拟跑1万到10万次或者更多，来计算概率是否符合预期。本教程先不涉及接口，只是单纯的去了解一下怎么取计算抽奖概率。

<!--more-->

### 准备

1.一个包含各种奖项的奖池。

2.了解随机模块[random](https://www.runoob.com/python/func-number-random.html)的用法

3.了解 [python格式化%s,%d,%f](https://blog.csdn.net/u013216667/article/details/51316971)

### 具体示例

我们这里设计一个含有6种不同奖项的列表，然后随机抽取1万次，然后计算各个奖品的概率，具体如下：

```python
import random
'''
奖项列表：
编号  奖品
1    土豪女友/男友
2    私人庄园
3    海景别墅
4    劳斯莱斯
5    iPhone12
6    纸巾一包

设计思路：
把所有奖品ID放一个列表，然后随机抽取，一共抽10000次，计算抽奖结果。

'''
# 1.定义一个抽奖列表，有抽奖编号组成
rewardIds = [1,2,3,4,5,6]
# 2.抽取10000次，并把抽到的结果放到一个列表内，
# 定义单次抽奖列表组合为lotteryResult,抽奖次数为：num1
lotteryResultSimple = []
num1 = 0
for i in range(10000):
    # 每次只抽一个奖品时
    '''
    从每次随机从列表取一个元素，用 random.choice(),
    取出的元素类型为元素本身的类型
    '''
    a = random.choice(rewardIds)
    lotteryResultSimple.append(a)
    num1+=1

# 定义每次抽多个奖品，抽奖奖励集合为lotteryResultMore,抽奖次数为：num2
lotteryResultMore = []
num2 = 0
for j in range(10000):
    #每次只抽一个奖品时
    '''
    从每次随机从列表取n个元素，用 random.sample(list,N)
    list所要去随机元素的数列，N为每次要取的数
    这时取出的随机元素，是一个数列
    '''
    b = random.sample(rewardIds,2)
    # 因为b是一个数列，所以不能用append把抽奖结果加进去了
    lotteryResultMore = lotteryResultMore + b
    num2 += 1

# 定义总抽奖次数为 num,所有奖品集合为lotteryResult
num = num1 + num2
lotteryResult = lotteryResultMore + lotteryResultSimple

# 总共抽到的奖品数量为 lotteryResultCount
lotteryResultCount = len(lotteryResult)
# 抽到土豪女友/男友的次数
rewardId1 = lotteryResult.count(1)
# 抽到私人庄园的次数
rewardId2 = lotteryResult.count(2)
# 抽到海景别墅的次数
rewardId3 = lotteryResult.count(3)
# 抽到劳斯莱斯的次数
rewardId4 = lotteryResult.count(4)
# 抽到iPhone12的次数
rewardId5 = lotteryResult.count(5)
# 抽到纸巾的次数
rewardId6 = lotteryResult.count(6)

print('共抽奖%s次，其中单抽%s次，二连抽%s次，共抽到奖品%s个'%(num,num1,num2,lotteryResultCount))
print("*"*30)  # 此处就是打印一个分割线
print('抽到土豪女友/男友的概率为    %.2f%%'%(rewardId1/lotteryResultCount*100))
print('抽到私人庄园的概率为        %.2f%%'%(rewardId2/lotteryResultCount*100))
print('抽到海景别墅的概率为        %.2f%%'%(rewardId3/lotteryResultCount*100))
print('抽到劳斯莱斯的概率为        %.2f%%'%(rewardId4/lotteryResultCount*100))
print('抽到iPhone12的概率为      %.2f%%'%(rewardId5/lotteryResultCount*100))
print('抽到纸巾的概率为           %.2f%%'%(rewardId6/lotteryResultCount*100))
```

以上就是一个概率的计算，以及结果的展示，具体用到的也就是一些基础知识，实际使用抽奖接口去抽奖并计算概率时，需要考虑的东西还有很多，我们后续再讲。

**小知识**

```python
#其他输出格式化例如 %s啦，%d基本大同小异，大家自行搜索练习 

a = 0.222222222
print("a显示小数点后两位：%.2f"%a)
# 输出为： a显示小数点后两位：0.22

print("a显示小数点后5位： %.5f"%a)
# 输出为：a显示小数点后5位： 0.22222

print("以百分号形式输出并保留小数点后两位 %.2f%%"%(a*100))
# 输出为： 以百分号形式输出并保留小数点后两位 22.22%
```



### 结语

面朝大海，春暖花开。

愿你一生努力，一生被爱。